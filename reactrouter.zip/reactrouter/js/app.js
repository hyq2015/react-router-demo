import React from 'react'
import { render } from 'react-dom'
import { Router, Route, IndexRoute, Link, IndexLink,hashHistory } from 'react-router'
const ACTIVE = { color: 'red' };
const App =  React.createClass({
    render(){
        return(
            <div>
        <h3>Ricky</h3>
        <ul>
            <li><Link to="/about" activeStyle={ACTIVE}>/about</Link></li>
            <li><Link to="/inbox" activeStyle={ACTIVE}>/inbox</Link></li>
            <li><Link to="/messages" activeStyle={ACTIVE}>/messages</Link></li>
            <li><IndexLink to="/" activeStyle={ACTIVE}>/ IndexLink</IndexLink></li>
        </ul>
        {this.props.children}
    </div>
    )
    }

});
const About = React.createClass({
    render() {
        return <h3>About</h3>
    }
});
const Inbox = React.createClass({
    render() {
        return (
            <div>
                <h3>Inbox</h3>
                <Link to="inbox/msg" activeStyle={ACTIVE}>/msg</Link>
                {this.props.children}
            </div>
        )
    }
});
const Message = React.createClass({
    render() {
        return <h3>Message</h3>
    }
});
const Msg = React.createClass({
    render() {
        return <h3>this is msg info</h3>
    }
});

render((
    <Router history={hashHistory}>
        <Route path="/" component={App}>
            <Route path="about" component={About} />
            <Route path="messages" component={Message} />
            <Route path="inbox" component={Inbox}>
                <Route path="msg" component={Msg} />
            </Route>
        </Route>
    </Router>
), document.getElementById("container1"));