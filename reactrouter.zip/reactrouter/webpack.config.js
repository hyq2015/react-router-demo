var webpack = require('webpack');
module.exports = {
    entry: [
        'webpack-dev-server/client?http://localhost:8080/', // WebpackDevServer host and port
        'webpack/hot/dev-server', // "only" prevents reload on syntax errors
        "./js/app.js"
    ],
    output: {
        path: '/build',
        publicPath: "http://localhost:8080/assets/",
        filename: "bundle.js",
    },
    module: {
        loaders: [
        { test: /\.jsx?$/, exclude: /node_modules/,
            // loader: 'babel' ,
            loaders: ['react-hot', 'babel?presets[]=es2015&presets[]=react'],
            exclude: /node_modules/
        }]
            // [
            // {test: /\.js?$/, loaders: ['react-hot', 'babel'], exclude: /node_modules/},
            // {test: /\.js$/, exclude: /node_modules/, loader: 'babel-loader'},
            // {test: /\.css$/, loader: "style!css"}]
    },
    // externals: [
    //     {
    //         react: {
    //             root: 'React',
    //             commonjs2: 'react',
    //             commonjs: 'react',
    //             amd: 'react'
    //         }
    //     }
    // ],
    resolve: {
        extensions: ['', '.js', '.json']
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new webpack.NoErrorsPlugin()
    ]
};