/**
 * Created by huangyq0811 on 2016/8/29.
 */
var gulp = require('gulp');
var webpack = require('gulp-webpack');
var webpackConfig = require('./webpack.config');
gulp.task("webpack1", function() {
    var myConfig = Object.create(webpackConfig);
    return gulp
        .src('/js/app.js')
        .pipe(webpack(myConfig))
        .pipe(gulp.dest('./build'));
});
gulp.task("default",function () {
    gulp.watch('./js/app.js', ['webpack1']);
});